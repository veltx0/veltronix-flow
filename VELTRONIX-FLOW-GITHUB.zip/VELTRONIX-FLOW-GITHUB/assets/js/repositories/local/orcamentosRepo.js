import {get, set, KEYS} from "./storage.js";
let demo = []; // registros marcados como demonstração: preservados no armazenamento, ocultos das telas
const read = () => { try { const a = JSON.parse(get(KEYS.q)); return Array.isArray(a) ? a : []; } catch { return []; } };
export const orcamentosRepo = {
  all: read,
  load(){
    const all = read(); demo = all.filter(r => r.origem === "demo");
    return all.filter(r => r.origem !== "demo").map(r => ({id:r.id, name:r.name, service:r.service, value:r.valueCents / 100, date:r.date, status:r.status, origem:"real", criadoEm:r.criadoEm}));
  },
  save(list){
    const rows = list.map(q => ({id:q.id, name:q.name, service:q.service, valueCents:Math.round(q.value * 100), date:q.date, status:q.status, origem:"real", criadoEm:q.criadoEm}));
    set(KEYS.q, JSON.stringify(rows.concat(demo)));
  }
};
