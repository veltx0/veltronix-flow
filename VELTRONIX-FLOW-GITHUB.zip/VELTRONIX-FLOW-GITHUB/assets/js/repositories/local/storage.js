export const KEYS = {q:"vf:v2:orcamentos", c:"vf:v2:config", meta:"vf:v2:meta", quar:"vf:v2:quarentena", legacyQ:"veltronix-flow-quotes", legacyB:"veltronix-flow-biz"};
export const get = k => { try { return localStorage.getItem(k); } catch { return null; } };
export const set = (k, v) => localStorage.setItem(k, v);
export const remove = k => { try { localStorage.removeItem(k); } catch {} };
