import {get, set, KEYS} from "./storage.js";
export const getBiz = () => { try { return JSON.parse(get(KEYS.c)).bizName || ""; } catch { return ""; } };
export const setBiz = name => set(KEYS.c, JSON.stringify({bizName:name}));
