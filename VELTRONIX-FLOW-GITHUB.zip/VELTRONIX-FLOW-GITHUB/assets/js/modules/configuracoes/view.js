import {$, brl, day, initials, uid} from "../../core/format.js";
import {store, commit, load} from "../../core/store.js";
import {notify} from "../../core/ui.js";
import {STATUS, addQuote} from "../../modules/orcamentos/service.js";
import {buildExport, importBackup} from "../../services/migration.js";
import {saveFile} from "../../services/files.js";
import {getBiz, setBiz} from "../../repositories/local/configRepo.js";

// Configurações
function applyBiz(){
  const n = getBiz();
  document.querySelector(".profile-name").textContent = n || "Meu negócio"; $("bizName").value = n;
}
$("saveBiz").onclick = () => { setBiz($("bizName").value.trim()); applyBiz(); notify("Nome salvo."); };
let armed = false;
$("clearData").onclick = () => {
  const btn = $("clearData"), label = "Apagar todos os orçamentos";
  if (!armed){ armed = true; btn.textContent = "Clique de novo para apagar tudo"; setTimeout(() => { armed = false; btn.textContent = label; }, 4000); return; }
  armed = false; btn.textContent = label; store.quotes = []; commit(); notify("Orçamentos apagados.");
};


$("exportBackup").onclick = async () => {
  const ok = await saveFile("veltronix-flow-backup.json", JSON.stringify(buildExport(), null, 2), "application/json");
  notify(ok ? "Backup exportado." : "Download cancelado.");
};
$("importBackup").onclick = () => $("importFile").click();
$("importFile").onchange = async e => {
  const f = e.target.files[0]; e.target.value = ""; if (!f) return;
  const box = $("backupMsg"); box.replaceChildren();
  const line = (txt, bad) => { const d = document.createElement("div"); d.textContent = txt; if (bad) d.style.color = "var(--red)"; box.append(d); };
  const r = importBackup(await f.text());
  if (!r.ok){ line("Importação cancelada. Nada foi gravado.", true); r.erros.forEach(m => line("• " + m, true)); notify("Importação cancelada: arquivo inválido."); return; }
  load(); store.emit(); applyBiz();
  line("Importação concluída: " + r.adicionados + " adicionados, " + r.ignorados + " já existiam e foram ignorados." + (r.nomeIgnorado ? " O nome do negócio atual foi mantido." : ""));
  notify("Backup importado.");
};
applyBiz();
