import {$, brl, day, initials, uid} from "../../core/format.js";
import {store, commit, load} from "../../core/store.js";
import {notify} from "../../core/ui.js";
import {STATUS, addQuote} from "../../modules/orcamentos/service.js";
import {getSampler} from "../../services/ai.js";

// Assistente IA
const chat = [];
export const tools = [
  {name:"salvar_orcamento", description:"Salva um novo orçamento no painel. Use só com cliente, serviço e valor informados pelo usuário.",
   inputSchema:{type:"object", properties:{cliente:{type:"string"}, servico:{type:"string"}, valor:{type:"number", description:"Valor em reais"}, status:{type:"string", enum:Object.keys(STATUS)}}, required:["cliente","servico","valor"]},
   execute:i => {
     const c = String(i.cliente || "").trim(), sv = String(i.servico || "").trim(), v = Number(i.valor);
     if (!c || !sv || !(v >= 0)) throw new Error("Dados incompletos");
     addQuote(c, sv, v, STATUS[i.status] ? i.status : "pending");
     return "Orçamento salvo: " + c + ", " + sv + ", " + brl(v);
   }},
  {name:"alterar_status", description:"Muda o status do orçamento mais recente de um cliente.",
   inputSchema:{type:"object", properties:{cliente:{type:"string"}, status:{type:"string", enum:Object.keys(STATUS)}}, required:["cliente","status"]},
   execute:i => {
     const q = store.quotes.find(x => x.name.trim().toLowerCase() === String(i.cliente || "").trim().toLowerCase());
     if (!q || !STATUS[i.status]) throw new Error("Orçamento não encontrado");
     q.status = i.status; commit(); return "Status atualizado para " + STATUS[i.status][0];
   }}
];
function bubble(role, text){
  const d = document.createElement("div"); d.className = "msg " + (role === "user" ? "user" : "bot"); d.textContent = text;
  $("chatLog").append(d); $("chatLog").scrollTop = 1e6; return d;
}
function buildPrompt(){
  const recent = store.quotes.slice(0,25).map(q => q.name + " | " + q.service + " | " + brl(q.value) + " | " + STATUS[q.status][0] + " | " + day(q.date)).join("\n") || "(nenhum orçamento ainda)";
  const biz = $("bizName").value.trim() || "o negócio do usuário";
  return "Você é o assistente do painel VELTRONIX FLOW, de " + biz + ". Responda em português do Brasil, de forma curta e direta.\n" +
    "Você cria orçamentos com a ferramenta salvar_orcamento, muda status com alterar_status e responde perguntas sobre os orçamentos abaixo.\n" +
    "Regras: nunca invente cliente, serviço ou valor; se faltar algum dado, pergunte só o que falta; só salve quando o usuário tiver informado os três; depois de salvar, confirme em uma frase; não prometa nada que as ferramentas não façam. Hoje é " + new Date().toLocaleDateString("pt-BR") + ".\n\nOrçamentos atuais:\n" + recent +
    "\n\nConversa:\n" + chat.map(m => (m.role === "user" ? "Usuário: " : "Assistente: ") + m.content).join("\n");
}
bubble("bot", "Olá! Me conte o pedido de um cliente (nome, serviço e valor) e eu salvo o orçamento. Também posso mudar o status de um orçamento ou responder dúvidas sobre os que você já tem.");
$("chatForm").onsubmit = async e => {
  e.preventDefault();
  const text = $("chatInput").value.trim(); if (!text) return;
  $("chatInput").value = ""; chat.push({role:"user", content:text}); bubble("user", text);
  const out = bubble("bot", "Pensando…"); $("chatSend").disabled = true;
  try {
    const sample = await getSampler();
    if (!sample) throw {code:"unavailable"};
    const r = await sample(buildPrompt(), {cache:false, tools, onText:u => { out.textContent = u.text; }});
    out.textContent = r.text || "Pronto."; chat.push({role:"assistant", content:out.textContent});
  } catch (err) {
    out.textContent = err && (err.code === "unavailable" || err.code === "not_granted")
      ? "O assistente só funciona na página publicada no Claude, com a permissão liberada. O resto do painel funciona normalmente."
      : "Não consegui responder agora. Tente de novo em instantes.";
  } finally { $("chatSend").disabled = false; }
};

