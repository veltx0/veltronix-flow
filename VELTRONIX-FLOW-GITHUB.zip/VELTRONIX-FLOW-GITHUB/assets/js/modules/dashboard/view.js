import {$, brl, day, initials, uid} from "../../core/format.js";
import {store, commit, load} from "../../core/store.js";
import {notify} from "../../core/ui.js";
import {STATUS, addQuote} from "../../modules/orcamentos/service.js";
function renderMetrics(){
  $("mCount").textContent = store.quotes.length;
  $("mOpen").textContent = store.quotes.filter(q => q.status !== "approved").length;
  $("mValue").textContent = brl(store.quotes.reduce((s,q) => s + q.value, 0));
  $("mClients").textContent = new Set(store.quotes.map(q => q.name.trim().toLowerCase())).size;
}

function renderActivity(){
  const box = $("activityList"); box.replaceChildren();
  const items = store.quotes.slice(0,4);
  $("actDesc").textContent = items.length ? "Últimos orçamentos criados." : "Nada por aqui ainda.";
  if (!items.length){ const e = document.createElement("div"); e.className = "empty"; e.textContent = "Quando você criar orçamentos, eles aparecem aqui."; box.append(e); }
  items.forEach(q => {
    const row = document.createElement("div"); row.className = "activity";
    const ic = document.createElement("div"); ic.className = "activity-icon"; ic.textContent = "▤"; ic.setAttribute("aria-hidden","true");
    const tx = document.createElement("div");
    const a = document.createElement("div"); a.className = "activity-text"; a.textContent = "Orçamento para " + q.name;
    const t = document.createElement("div"); t.className = "activity-time"; t.textContent = brl(q.value) + " · " + STATUS[q.status][0] + " · " + day(q.date);
    tx.append(a, t); row.append(ic, tx); box.append(row);
  });
}

// Gráfico
function drawChart(p){
  const days = +p, n = days === 7 ? 7 : days === 30 ? 10 : 9, size = days / n;
  const now = new Date(); now.setHours(0,0,0,0);
  const counts = Array(n).fill(0); let total = 0;
  store.quotes.forEach(q => {
    const ago = Math.round((now - new Date(q.date + "T00:00:00")) / 864e5);
    if (ago >= 0 && ago < days){ counts[n - 1 - Math.floor(ago / size)]++; total++; }
  });
  const max = Math.max(3, Math.ceil(Math.max(...counts) / 3) * 3), L = 45, R = 585, T = 25, B = 160;
  [0,1,2,3].forEach(i => $("y" + i).textContent = Math.round(max * (3 - i) / 3));
  const pts = counts.map((c,i) => [L + (R-L) * i / (n-1), B - c / max * (B-T)]);
  const line = pts.map((q,i) => (i ? "L" : "M") + q[0].toFixed(1) + "," + q[1].toFixed(1)).join(" ");
  $("chartLine").setAttribute("d", line);
  $("chartArea").setAttribute("d", line + " L" + R + "," + B + " L" + L + "," + B + " Z");
  const last = pts[n-1];
  $("chartPoint").setAttribute("cx", last[0]); $("chartPoint").setAttribute("cy", last[1]);
  const fmt = ago => new Date(now - ago * 864e5).toLocaleDateString("pt-BR", {day:"2-digit", month:"2-digit"});
  $("x0").textContent = fmt(days - 1); $("x1").textContent = fmt(Math.round(days * 2 / 3));
  $("x2").textContent = fmt(Math.round(days / 3)); $("x3").textContent = "Hoje";
  $("chartNote").textContent = total ? total + (total === 1 ? " orçamento criado" : " orçamentos criados") + " em " + days + " dias" : "Nenhum orçamento criado neste período";
}
$("periodSelect").onchange = e => drawChart(e.target.value);


store.subscribe(() => { renderMetrics(); renderActivity(); drawChart($("periodSelect").value); });
