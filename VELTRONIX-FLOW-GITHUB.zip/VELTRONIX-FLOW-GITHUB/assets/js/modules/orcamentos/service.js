import {uid} from "../../core/format.js";
import {store, commit} from "../../core/store.js";
// Regras de negócio dos orçamentos (sem acesso direto ao DOM nem ao armazenamento).
export const STATUS = {pending:["Pendente","badge-pending"], approved:["Aprovado","badge-approved"], review:["Em análise","badge-review"]};
export function addQuote(name, service, value, status){
  store.quotes.unshift({id:uid(), criadoEm:new Date().toISOString(), origem:"real", name, service, value, date:new Date().toLocaleDateString("sv-SE"), status});
  store.quotes.sort((a,b) => b.date.localeCompare(a.date));
  commit();
}
