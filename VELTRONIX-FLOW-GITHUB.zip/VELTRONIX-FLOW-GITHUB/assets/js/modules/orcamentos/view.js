import {$, brl, day, initials, uid} from "../../core/format.js";
import {store, commit, load} from "../../core/store.js";
import {notify} from "../../core/ui.js";
import {STATUS, addQuote} from "../../modules/orcamentos/service.js";
import {saveFile} from "../../services/files.js";

function render(){
  const filter = $("statusFilter").value;
  const body = $("quotesBody"); body.replaceChildren();
  const list = store.quotes.filter(q => !filter || q.status === filter);
  if (!list.length){
    const tr = body.insertRow(), td = tr.insertCell();
    td.colSpan = 6; td.className = "empty";
    td.textContent = store.quotes.length ? "Nenhum orçamento com esse status." : "Nenhum orçamento ainda. Use “Novo orçamento” para criar o primeiro.";
  }
  list.forEach(q => {
    const tr = body.insertRow();
    const c = tr.insertCell(), box = document.createElement("div"); box.className = "client";
    const av = document.createElement("div"); av.className = "client-avatar"; av.textContent = initials(q.name);
    const nm = document.createElement("div"); nm.className = "client-name"; nm.textContent = q.name;
    box.append(av, nm); c.append(box);
    tr.insertCell().textContent = q.service;
    tr.insertCell().textContent = brl(q.value);
    tr.insertCell().textContent = day(q.date);
    const sc = tr.insertCell(), sel = document.createElement("select");
    sel.setAttribute("aria-label", "Status do orçamento de " + q.name);
    Object.keys(STATUS).forEach(k => sel.add(new Option(STATUS[k][0], k, false, k === q.status)));
    sel.onchange = () => { q.status = sel.value; commit(); notify("Status atualizado."); };
    sc.append(sel);
    const ac = tr.insertCell(), del = document.createElement("button");
    del.className = "text-btn"; del.textContent = "Excluir"; del.setAttribute("aria-label", "Excluir orçamento de " + q.name);
    del.onclick = () => { store.quotes = store.quotes.filter(x => x !== q); commit(); notify("Orçamento excluído."); };
    ac.append(del);
  });
  $("countLabel").textContent = list.length + (list.length === 1 ? " orçamento" : " orçamentos");
}

// Formulário
const dlg = $("quoteDialog"), form = $("quoteForm");
const openForm = () => { form.reset(); dlg.showModal(); form.name.focus(); };
$("newQuote").onclick = openForm;
$("cancelQuote").onclick = () => dlg.close();
form.addEventListener("submit", e => {
  e.preventDefault();
  const f = new FormData(form), value = parseFloat(f.get("value"));
  const name = String(f.get("name")).trim(), service = String(f.get("service")).trim();
  if (!name || !service || !(value >= 0)) { notify("Preencha cliente, serviço e valor."); return; }
  addQuote(name, service, value, f.get("status")); dlg.close(); notify("Orçamento salvo.");
});
$("statusFilter").onchange = render;

// Exportar CSV (respeita o filtro)
$("exportButton").onclick = () => {
  const f = $("statusFilter").value, list = store.quotes.filter(q => !f || q.status === f);
  if (!list.length) { notify("Não há orçamentos para exportar."); return; }
  const rows = [["Cliente","Serviço","Valor","Data","Status"]].concat(
    list.map(q => [q.name, q.service, q.value.toFixed(2), day(q.date), STATUS[q.status][0]]));
  const csv = "\uFEFF" + rows.map(r => r.map(c => '"' + String(c).replace(/"/g,'""') + '"').join(";")).join("\r\n");
  saveFile("veltronix-flow-orcamentos.csv", csv).then(ok => notify(ok ? "CSV exportado." : "Download cancelado."));
};

store.subscribe(render);
