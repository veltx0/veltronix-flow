import {$, brl, day, initials, uid} from "../../core/format.js";
import {store, commit, load} from "../../core/store.js";
import {notify} from "../../core/ui.js";
import {STATUS, addQuote} from "../../modules/orcamentos/service.js";
function renderClients(){
  const cb = $("clientsBody"); cb.replaceChildren();
  const map = new Map();
  store.quotes.forEach(q => {
    const k = q.name.trim().toLowerCase(), c = map.get(k) || {name:q.name, n:0, sum:0, last:""};
    c.n++; c.sum += q.value; if (q.date > c.last) c.last = q.date; map.set(k, c);
  });
  if (!map.size){ const td = cb.insertRow().insertCell(); td.colSpan = 4; td.className = "empty"; td.textContent = "Os clientes aparecem aqui quando você criar orçamentos."; }
  [...map.values()].sort((a,b) => b.sum - a.sum).forEach(c => {
    const r = cb.insertRow(); r.insertCell().textContent = c.name; r.insertCell().textContent = c.n;
    r.insertCell().textContent = brl(c.sum); r.insertCell().textContent = day(c.last);
  });
}

store.subscribe(renderClients);
