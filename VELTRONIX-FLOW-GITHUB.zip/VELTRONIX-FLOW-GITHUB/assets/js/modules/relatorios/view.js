import {$, brl, day, initials, uid} from "../../core/format.js";
import {store, commit, load} from "../../core/store.js";
import {notify} from "../../core/ui.js";
import {STATUS, addQuote} from "../../modules/orcamentos/service.js";
function renderReports(){
  const rb = $("reportsBody"); rb.replaceChildren();
  if (!store.quotes.length){ const e = document.createElement("div"); e.className = "empty"; e.textContent = "Crie orçamentos para ver os relatórios."; rb.append(e); return; }
  const total = store.quotes.reduce((t,q) => t + q.value, 0), approved = store.quotes.filter(q => q.status === "approved");
  const lines = [["Ticket médio", brl(total / store.quotes.length)], ["Taxa de aprovação", Math.round(100 * approved.length / store.quotes.length) + "%"]];
  Object.keys(STATUS).forEach(k => {
    const l = store.quotes.filter(q => q.status === k);
    lines.push([STATUS[k][0], l.length + " · " + brl(l.reduce((t,q) => t + q.value, 0))]);
  });
  const by = {}; store.quotes.forEach(q => by[q.service] = (by[q.service] || 0) + q.value);
  const top = Object.entries(by).sort((a,b) => b[1] - a[1])[0];
  lines.push(["Serviço que mais rende", top[0] + " · " + brl(top[1])]);
  lines.forEach(([k,v]) => {
    const row = document.createElement("div"); row.className = "rep-row";
    const a = document.createElement("span"), b = document.createElement("strong");
    a.textContent = k; b.textContent = v; row.append(a, b); rb.append(row);
  });
}


store.subscribe(renderReports);
