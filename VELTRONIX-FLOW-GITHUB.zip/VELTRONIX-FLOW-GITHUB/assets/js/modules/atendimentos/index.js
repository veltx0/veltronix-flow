// Placeholder: o módulo Atendimentos ainda não tem tela (comportamento igual ao da v1.3).
export default {id:"atendimentos", estado:"em-desenvolvimento"};
