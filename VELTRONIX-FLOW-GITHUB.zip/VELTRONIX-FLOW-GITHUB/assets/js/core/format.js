export const $ = id => document.getElementById(id);
export const brl = n => n.toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
export const day = iso => iso.split("-").reverse().join("/");
export const initials = name => name.split(/\s+/).filter(Boolean).slice(0,2).map(w => w[0].toUpperCase()).join("");
export const uid = () => (globalThis.crypto && crypto.randomUUID) ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2);
