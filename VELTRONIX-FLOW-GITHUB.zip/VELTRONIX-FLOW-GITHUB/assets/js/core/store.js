import {orcamentosRepo} from "../repositories/local/orcamentosRepo.js";
const listeners = [];
export const store = {quotes: [], subscribe(fn){ listeners.push(fn); }, emit(){ listeners.forEach(f => f()); }};
export function load(){ store.quotes = orcamentosRepo.load(); }
export function commit(){ orcamentosRepo.save(store.quotes); store.emit(); }
