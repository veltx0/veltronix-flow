import {$, brl, day, initials, uid} from "../core/format.js";
import {store, commit, load} from "../core/store.js";
import {notify} from "../core/ui.js";
import {STATUS, addQuote} from "../modules/orcamentos/service.js";
// Navegação
const sidebar = $("sidebar"), menuToggle = $("menuToggle");
function closeMenu(){ sidebar.classList.remove("open"); menuToggle.setAttribute("aria-expanded","false"); }
menuToggle.onclick = () => menuToggle.setAttribute("aria-expanded", String(sidebar.classList.toggle("open")));
document.addEventListener("click", e => {
  if (innerWidth <= 700 && sidebar.classList.contains("open") && !sidebar.contains(e.target) && !menuToggle.contains(e.target)) closeMenu();
});
document.addEventListener("keydown", e => { if (e.key === "Escape") closeMenu(); });

const VIEWS = {
  "Dashboard":["Visão geral","Acompanhe os principais indicadores do seu negócio.",["dashboard","quotesCard"]],
  "Orçamentos":["Orçamentos","Crie, filtre e exporte seus orçamentos.",["quotesCard"]],
  "Clientes":["Clientes","Quem já pediu orçamento com você.",["clientsCard"]],
  "Assistente IA":["Assistente IA","Peça ao assistente para criar e organizar orçamentos.",["assistantCard"]],
  "Relatórios":["Relatórios","Resumo do que você já registrou.",["reportsCard"]],
  "Configurações":["Configurações","Ajustes do seu painel.",["settingsCard"]]
};
const ALL = ["dashboard","quotesCard","clientsCard","assistantCard","reportsCard","settingsCard"];
document.querySelectorAll(".nav button").forEach(btn => btn.onclick = () => {
  document.querySelectorAll(".nav button").forEach(i => { i.classList.remove("active"); i.removeAttribute("aria-current"); });
  btn.classList.add("active"); btn.setAttribute("aria-current","page");
  const page = btn.dataset.page, v = VIEWS[page];
  ALL.forEach(id => $(id).hidden = !(v && v[2].includes(id)));
  $("breadcrumbPage").textContent = page;
  $("pageTitle").textContent = v ? v[0] : page;
  $("pageSubtitle").textContent = v ? v[1] : "Esta área será implementada nas próximas etapas do VELTRONIX FLOW.";
  if (!v) notify("“" + page + "” ainda está em desenvolvimento.");
  closeMenu();
});


$("helpButton").onclick = () => notify("VELTRONIX FLOW v1.4 — painel em desenvolvimento.");
$("aboutLink").onclick = e => { e.preventDefault(); $("sobre").scrollIntoView({behavior:"smooth"}); };
