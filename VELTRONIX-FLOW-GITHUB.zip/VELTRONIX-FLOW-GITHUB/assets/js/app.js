import {migrationResult as r} from "./services/boot.js"; // 1º: migração e carga dos dados
import "./core/registry.js";
import "./modules/orcamentos/view.js";
import "./modules/dashboard/view.js";
import "./modules/clientes/view.js";
import "./modules/relatorios/view.js";
import "./modules/atendimentos/index.js";
import "./modules/assistente/view.js";
import "./modules/configuracoes/view.js";
import {store} from "./core/store.js";
import {notify} from "./core/ui.js";
store.emit();
if (r.status === "erro") notify("Não foi possível migrar os dados antigos. Eles foram mantidos intactos.");
else if (r.status === "migrado") notify(r.migrados + " orçamento(s) migrado(s). Cópia de segurança criada.");
