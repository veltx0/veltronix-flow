import {get, set, remove, KEYS} from "../repositories/local/storage.js";
import {getBiz, setBiz} from "../repositories/local/configRepo.js";
import {uid} from "../core/format.js";
const ST = ["pending","approved","review"];
const DEMO = ["Mariana Costa|Desenvolvimento web|1800|2026-10-14|pending","Rafael Lima|Site institucional|2500|2026-10-13|approved","Ana Souza|Manutenção de site|450|2026-10-12|review"];
const stamp = () => new Date().toISOString();

// Valida um registro (formato antigo "value" em reais ou novo "valueCents"). Retorna {rec} ou {erro}.
export function toRecord(r){
  if (!r || typeof r !== "object") return {erro:"o registro não é um objeto"};
  if (typeof r.name !== "string" || !r.name.trim()) return {erro:"cliente vazio"};
  if (typeof r.service !== "string" || !r.service.trim()) return {erro:"serviço vazio"};
  const cents = Number.isInteger(r.valueCents) ? r.valueCents : (typeof r.value === "number" && isFinite(r.value) ? Math.round(r.value * 100) : NaN);
  if (!(cents >= 0) || cents > 1e11) return {erro:"valor inválido"};
  if (typeof r.date !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(r.date)) return {erro:"data inválida (use AAAA-MM-DD)"};
  if (!ST.includes(r.status)) return {erro:"status inválido"};
  const demo = r.origem === "demo" || DEMO.includes([r.name, r.service, cents / 100, r.date, r.status].join("|"));
  return {rec:{id:r.id || uid(), name:r.name, service:r.service, valueCents:cents, date:r.date, status:r.status, origem:demo ? "demo" : "real", criadoEm:r.criadoEm || stamp()}};
}

// Migração v1 -> v2. Nunca altera nem apaga as chaves antigas.
export function migrate(){
  if (get(KEYS.meta)) return {status:"ja-migrado"};
  const rawQ = get(KEYS.legacyQ), rawB = get(KEYS.legacyB);
  const meta = extra => set(KEYS.meta, JSON.stringify(Object.assign({schemaVersion:2, migratedAt:stamp()}, extra)));
  try {
    if (rawQ === null && rawB === null){ meta({origem:"instalacao-nova"}); return {status:"novo"}; }
    const bk = "vf:backup:v1:" + stamp();
    set(bk, JSON.stringify({quotesRaw:rawQ, bizRaw:rawB}));               // 1. cópia exata do texto original
    if (get(bk) === null) throw new Error("não foi possível gravar o snapshot");
    let arr = [], quar = [], invalidos = 0;
    try { arr = JSON.parse(rawQ || "[]"); if (!Array.isArray(arr)) throw 0; }
    catch { quar.push({motivo:"JSON inválido ou não é uma lista", original:rawQ}); arr = []; }
    const ok = [];
    arr.forEach((r, i) => { const x = toRecord(r); if (x.rec) ok.push(x.rec); else { invalidos++; quar.push({motivo:x.erro, indice:i, original:r}); } });
    set(KEYS.q, JSON.stringify(ok)); set(KEYS.quar, JSON.stringify(quar)); set(KEYS.c, JSON.stringify({bizName:rawB || ""}));
    const back = JSON.parse(get(KEYS.q));                                  // 2. validação por releitura
    const soma = a => a.reduce((t, r) => t + r.valueCents, 0);
    if (back.length !== ok.length || soma(back) !== soma(ok) || ok.length + invalidos !== arr.length) throw new Error("validação falhou");
    meta({backup:bk, migrados:ok.length, quarentena:quar.length});         // 3. marca como concluída por último
    return {status:"migrado", migrados:ok.length, quarentena:quar.length, backup:bk};
  } catch (e) {
    [KEYS.q, KEYS.quar, KEYS.c].forEach(remove);                           // remove só o que a migração criou
    try { meta({falhou:String(e && e.message || e)}); } catch {}
    return {status:"erro", erro:String(e && e.message || e)};
  }
}

export function buildExport(){
  let all = []; try { all = JSON.parse(get(KEYS.q) || "[]"); } catch {}
  return {app:"veltronix-flow", formato:1, exportadoEm:stamp(), config:{bizName:getBiz()}, orcamentos:all};
}

// Importação: valida tudo antes de gravar, não duplica e não sobrescreve nada existente.
export function importBackup(text){
  let d; try { d = JSON.parse(text); } catch { return {ok:false, erros:["O arquivo não é um JSON válido."]}; }
  if (!d || d.app !== "veltronix-flow" || !Array.isArray(d.orcamentos)) return {ok:false, erros:["Arquivo não reconhecido: esperado um backup do VELTRONIX FLOW."]};
  if (d.orcamentos.length > 5000) return {ok:false, erros:["Arquivo grande demais (máximo de 5000 orçamentos)."]};
  const novos = [], erros = [];
  d.orcamentos.forEach((r, i) => { const x = toRecord(r); if (x.rec) novos.push(x.rec); else erros.push("Orçamento " + (i + 1) + ": " + x.erro); });
  if (erros.length) return {ok:false, erros:erros.slice(0, 10).concat(erros.length > 10 ? ["…e mais " + (erros.length - 10) + " erros."] : [])};
  let atual = []; try { atual = JSON.parse(get(KEYS.q) || "[]"); } catch {}
  const key = r => [r.name.trim().toLowerCase(), r.service.trim().toLowerCase(), r.valueCents, r.date, r.status].join("|");
  const vistos = new Set(atual.map(key)), ids = new Set(atual.map(r => r.id)); const add = []; let ignorados = 0;
  novos.forEach(r => { const k = key(r); if (vistos.has(k)){ ignorados++; return; } vistos.add(k); if (ids.has(r.id)) r.id = uid(); ids.add(r.id); add.push(r); });
  const snap = "vf:backup:import:" + stamp();
  try {
    set(snap, JSON.stringify(atual));
    const merged = add.concat(atual).sort((a, b) => b.date.localeCompare(a.date));
    set(KEYS.q, JSON.stringify(merged));
    if (JSON.parse(get(KEYS.q)).length !== atual.length + add.length) throw new Error("conferência após gravar falhou");
  } catch (e) { try { set(KEYS.q, JSON.stringify(atual)); } catch {} return {ok:false, erros:["Falha ao gravar; os dados anteriores foram restaurados. " + (e.message || "")]}; }
  let nomeIgnorado = false; const nome = d.config && typeof d.config.bizName === "string" ? d.config.bizName.trim() : "";
  if (nome){ if (!getBiz()) setBiz(nome); else if (getBiz() !== nome) nomeIgnorado = true; }
  return {ok:true, adicionados:add.length, ignorados, nomeIgnorado};
}
