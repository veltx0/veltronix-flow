import {migrate} from "./migration.js";
import {load} from "../core/store.js";
export const migrationResult = migrate(); // roda antes de qualquer módulo de tela
load();
