// Só existe dentro da página publicada no Claude. Em outra hospedagem retorna null (o assistente avisa que está indisponível).
export async function getSampler(){ try { return window.claude ? await claude.use("sample") : null; } catch { return null; } }
