export async function saveFile(name, text, mime = "text/csv;charset=utf-8;"){
  try {
    const d = window.claude && await claude.use("downloads");
    if (d){ await d.save({filename:name, data:text}); return true; }
  } catch { return false; }
  const url = URL.createObjectURL(new Blob([text], {type:mime}));
  const a = document.createElement("a"); a.href = url; a.download = name;
  document.body.append(a); a.click(); a.remove(); URL.revokeObjectURL(url); return true;
}
