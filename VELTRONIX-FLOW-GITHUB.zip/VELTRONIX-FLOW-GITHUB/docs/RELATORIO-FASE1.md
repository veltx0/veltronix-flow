# Relatório técnico — Fase 1

Gerado a partir do que foi de fato feito e executado. Origem do código: `backup/index.v1.3.backup.html` (SHA-256 `cbc45006…725a`, verificado com `sha256sum -c`).

## 1. O que mudou de fato
- O arquivo único (HTML + CSS + JS) foi dividido em 4 CSS, 1 HTML e 20 arquivos JavaScript em módulos nativos. O código das telas foi **movido do original por fatiamento automático** e adaptado só nos pontos de integração (imports, armazenamento e estado compartilhado).
- Estado compartilhado: `core/store.js` (lista de orçamentos + assinaturas). Antes eram variáveis globais.
- Armazenamento: repositório local (`repositories/local/`), com valores em centavos inteiros e `id` por registro.
- Migração v1 -> v2 com snapshot, quarentena e validação (`services/migration.js`).
- **Novo, autorizado:** exportar/importar backup JSON (Configurações) e `legacy/index.v1.3-com-exportacao.html`.

## 2. Desvios do plano apresentado (todos intencionais)
- `docs/decisoes.md` e `tests/README.md` não foram criados separadamente: o conteúdo está no `README.md` e neste relatório.
- Código morto do botão "Exportar CSV" (linhas após um `return;`) não foi levado para a versão modular. O arquivo `backup/` e `legacy/` mantêm o original.
- O texto de versão do rodapé mudou para "Versão 1.4 (Fase 1)" e o botão "?" passou a citar v1.4.
- Configurações ganhou os botões de backup (única mudança visual, autorizada). Essa tela **não** foi comparada por captura de tela.
- Registros que coincidem exatamente (nome, serviço, valor, data, status) com os 3 exemplos antigos são marcados `demo`: **preservados** e ocultos das telas, em vez de descartados como na v1.3.
- "Apagar todos os orçamentos" remove só os registros reais; os `demo` preservados continuam guardados.

## 3. Funcionalidades preservadas e não preservadas
Todas as funcionalidades da v1.3 foram mantidas. Nenhuma foi removida. Atendimentos continua placeholder, como antes. Não há edição dos campos de um orçamento (só do status), como na v1.3.

## 4. Verificações executadas (não são testes de navegador)
- CSS dividido concatena **exatamente** igual ao CSS original: sim.
- Verificação estática (`E3`): sem caminhos absolutos, sem URLs externas, todos os `import` apontam para arquivos existentes.

## 5. Testes de regressão executados (Chromium headless via Playwright, servidor local)
Executado em 2026-10-16T05:06:25.265Z: **50 de 50 passaram**, 0 falharam.

| Resultado | Teste |
|---|---|
| ✅ passou | A1 carrega sem erros de script nem 404 |
| ✅ passou | A2 estado inicial vazio e sem dados fictícios |
| ✅ passou | A3 criação: linhas, contadores, valor e clientes |
| ✅ passou | A3b criação aparece em Atividades recentes |
| ✅ passou | A4 mudança de status atualiza pendentes e persiste na tela |
| ✅ passou | A5 filtros por status |
| ✅ passou | A6 exclusão |
| ✅ passou | A7 gráfico do dashboard e troca de período |
| ✅ passou | A7b Clientes e Relatórios refletem os dados |
| ✅ passou | A8 persistência após recarregar |
| ✅ passou | A9 exportação CSV (BOM, cabeçalho, aspas e ponto e vírgula) |
| ✅ passou | A10 configurações: nome do negócio aplicado |
| ✅ passou | A10b nome do negócio persiste |
| ✅ passou | A10c apagar exige dois cliques e zera os orçamentos |
| ✅ passou | A11 Atendimentos continua como aviso de 'em desenvolvimento' |
| ✅ passou | A12 assistente fora do Claude mostra o aviso de indisponibilidade |
| ✅ passou | A12b ferramentas do assistente (chamadas diretamente) salvam, mudam status e validam |
| ✅ passou | A13 nenhum erro de script durante todo o fluxo funcional |
| ✅ passou | B1 menu móvel: fechado, abre pelo botão e fecha ao navegar |
| ✅ passou | B2 sem rolagem horizontal em 390px |
| ✅ passou | C1 chaves antigas intactas após migrar |
| ✅ passou | C2 snapshot do original gravado com o texto exato |
| ✅ passou | C3 resultado: 3 migrados (2 reais + 1 demo), 2 em quarentena |
| ✅ passou | C3b valores em centavos inteiros e ids únicos |
| ✅ passou | C4 tela mostra só dados reais; demo oculto; nome do negócio migrado |
| ✅ passou | C5 aviso de migração exibido |
| ✅ passou | C6 idempotente: recarregar não cria novo backup nem altera dados |
| ✅ passou | C7 usar o app não toca nas chaves antigas e preserva o registro demo |
| ✅ passou | C8 sem erros no console |
| ✅ passou | C9 JSON corrompido: vai para quarentena, original intacto, app abre vazio |
| ✅ passou | C10 instalação nova: sem backup e sem dados |
| ✅ passou | D1 exportação gera JSON válido, completo e sem alterar dados |
| ✅ passou | D2 importar o mesmo arquivo não duplica (0 adicionados, 2 ignorados) |
| ✅ passou | D3 importar com 1 novo adiciona só o novo e cria snapshot |
| ✅ passou | D3b tela atualiza após importar |
| ✅ passou | D4 arquivo inválido: erro claro e nada gravado |
| ✅ passou | D5 registros inválidos: lista os erros e não grava nada (nem os válidos) |
| ✅ passou | D6 arquivo de outro aplicativo é recusado |
| ✅ passou | E1 funciona em subpasta (/app/x/) sem 404 e persiste |
| ✅ passou | E2 servidor sensível a maiúsculas devolve 404 para caminho com caixa errada |
| ✅ passou | E3 (verificação estática executada) sem caminhos absolutos, sem URLs externas e todos os imports existem |
| ✅ passou | F1 exportação da página antiga é somente leitura e gera formato importável |
| ✅ passou | F2 dados da página antiga chegam à versão modular via importação |
| ✅ passou | G1 mesmo cenário no original v1.3 e na versão modular produz resultados idênticos |
| ✅ passou | G2 captura de tela 1280px (vazio) idêntica ao original (exceto o texto de versão do rodapé, que mudou de propósito) |
| ✅ passou | G2 captura de tela 1280px (com dados) idêntica ao original (exceto o texto de versão do rodapé, que mudou de propósito) |
| ✅ passou | G2 captura de tela 820px (vazio) idêntica ao original (exceto o texto de versão do rodapé, que mudou de propósito) |
| ✅ passou | G2 captura de tela 820px (com dados) idêntica ao original (exceto o texto de versão do rodapé, que mudou de propósito) |
| ✅ passou | G2 captura de tela 390px (vazio) idêntica ao original (exceto o texto de versão do rodapé, que mudou de propósito) |
| ✅ passou | G2 captura de tela 390px (com dados) idêntica ao original (exceto o texto de versão do rodapé, que mudou de propósito) |

Observações sobre a cobertura:
- O comparativo com o original (G1/G2) roda o mesmo cenário na v1.3 e na versão modular. G2 ignora o texto de versão do rodapé, que mudou de propósito.
- Durante o desenvolvimento houve falhas, já resolvidas: um defeito real meu (`saveFile` sem import na tela de orçamentos, o CSV não baixava), um teste com expectativa errada (A7b) e as capturas de tela, que no começo diferiam só pelo texto de versão do rodapé (mudança intencional, agora ignorada no comparativo). Os números acima são da execução final.

## 6. O que NÃO foi testado
- Conversa real do Assistente IA com o Claude (depende da página publicada no Claude; só a mensagem de indisponibilidade e as ferramentas foram exercitadas)
- Navegadores além do Chromium (Firefox, Safari) e aparelhos reais com toque
- Publicação real em hospedagem estática (apenas servidor local e subpasta simulados)
- Página já publicada no Claude (não foi alterada nem republicada)
- Exportação pelo recurso de downloads do Claude (só o caminho alternativo por link de download foi exercitado)

## 7. Riscos e limitações
- Os dados da página já publicada no Claude só podem ser exportados se ela for republicada com o botão de exportação (não feito, por instrução).
- `localStorage` é por navegador e por endereço: não há sincronização entre aparelhos (previsto para a fase do Supabase).
- A migração não foi exercitada com grandes volumes de dados.
- `crypto.randomUUID` exige contexto seguro (HTTPS ou localhost); há alternativa quando indisponível, não testada em navegador antigo.
