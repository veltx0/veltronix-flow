# Inventário técnico — VELTRONIX FLOW (Fase 1)

## Arquivos (tamanho em bytes)
| Arquivo | Bytes |
|---|---|
| `assets/css/base.css` | 292 |
| `assets/css/components.css` | 6184 |
| `assets/css/layout.css` | 2840 |
| `assets/css/tokens.css` | 170 |
| `assets/js/app.js` | 712 |
| `assets/js/core/format.js` | 468 |
| `assets/js/core/registry.js` | 2362 |
| `assets/js/core/store.js` | 348 |
| `assets/js/core/ui.js` | 241 |
| `assets/js/modules/assistente/view.js` | 4028 |
| `assets/js/modules/atendimentos/index.js` | 158 |
| `assets/js/modules/clientes/view.js` | 1023 |
| `assets/js/modules/configuracoes/view.js` | 2175 |
| `assets/js/modules/dashboard/view.js` | 3260 |
| `assets/js/modules/orcamentos/service.js` | 612 |
| `assets/js/modules/orcamentos/view.js` | 3457 |
| `assets/js/modules/relatorios/view.js` | 1499 |
| `assets/js/repositories/local/configRepo.js` | 228 |
| `assets/js/repositories/local/orcamentosRepo.js` | 851 |
| `assets/js/repositories/local/storage.js` | 395 |
| `assets/js/services/ai.js` | 259 |
| `assets/js/services/boot.js` | 171 |
| `assets/js/services/files.js` | 476 |
| `assets/js/services/migration.js` | 5861 |
| `backup/SHA256SUMS.txt` | 89 |
| `backup/index.v1.3.backup.html` | 36051 |
| `index.html` | 10469 |
| `legacy/index.v1.3-com-exportacao.html` | 37027 |
| `tests/fixtures/legacy-DEMONSTRACAO.json` | 647 |
| `tests/run.mjs` | 20254 |
| `tests/server.mjs` | 1562 |

Os arquivos `docs/*.md` e `tests/resultados.json` não entram na tabela (são gerados por último).

## Comportamentos e situação real
| Funcionalidade | Situação | Onde está |
|---|---|---|
| Criar orçamento (formulário) | real | `modules/orcamentos/view.js` + `service.js` |
| Mudar status na tabela | real (é a única "edição" que existe; não há edição dos demais campos) | `modules/orcamentos/view.js` |
| Excluir orçamento | real | `modules/orcamentos/view.js` |
| Filtro por status | real | `modules/orcamentos/view.js` |
| Exportar CSV (respeita o filtro) | real | `modules/orcamentos/view.js` + `services/files.js` |
| Dashboard: métricas, gráfico, atividades | real, calculado dos orçamentos | `modules/dashboard/view.js` |
| Clientes | derivado dos orçamentos (não é cadastro) | `modules/clientes/view.js` |
| Relatórios | derivado dos orçamentos | `modules/relatorios/view.js` |
| Configurações: nome do negócio, apagar orçamentos | real | `modules/configuracoes/view.js` |
| Exportar / importar backup JSON | **novo (autorizado), só para migração** | `services/migration.js` + `modules/configuracoes/view.js` |
| Migração do armazenamento v1 -> v2 | **novo** | `services/migration.js`, `services/boot.js` |
| Assistente IA | real **somente na página publicada no Claude**; fora dela mostra aviso | `modules/assistente/view.js`, `services/ai.js` |
| Atendimentos | placeholder (aviso "em desenvolvimento") | `modules/atendimentos/index.js` + `core/registry.js` |
| Menu responsivo, navegação, avisos | real | `core/registry.js`, `core/ui.js` |
| Botão "?" e "Sobre o projeto" | só aviso / rolagem | `core/registry.js` |

## Armazenamento (localStorage)
- Antigas (nunca alteradas pela Fase 1): `veltronix-flow-quotes`, `veltronix-flow-biz`.
- Novas: `vf:v2:meta`, `vf:v2:orcamentos`, `vf:v2:config`, `vf:v2:quarentena`.
- Cópias de segurança: `vf:backup:v1:<data-hora>` (original exato) e `vf:backup:import:<data-hora>` (estado anterior a cada importação).
- Registro v2: `id`, `name`, `service`, `valueCents` (inteiro), `date` (AAAA-MM-DD), `status`, `origem` (`real` | `demo`), `criadoEm`.
