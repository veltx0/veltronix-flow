// Testes de regressão em navegador real (Playwright + Chromium). Uso: node tests/run.mjs
import {createRequire} from "node:module";
import {fileURLToPath} from "node:url";
import {dirname, join} from "node:path";
import {readFileSync, writeFileSync, readdirSync, existsSync, statSync} from "node:fs";
import {startServer} from "./server.mjs";
const here = dirname(fileURLToPath(import.meta.url)), root = join(here, "..");
const req = createRequire(import.meta.url);
const load = n => { try { return req(n); } catch { return createRequire("/home/claude/.npm-global/lib/node_modules/")(n); } };
const {chromium} = load("playwright"); let sharp = null; try { sharp = load("sharp"); } catch {}
const R = []; const t = (teste, ok, d = "") => { R.push({teste, ok:!!ok, detalhe:String(d)}); console.log((ok ? "OK    " : "FALHA ") + teste + (ok ? "" : "  -> " + d)); };
const fx = JSON.parse(readFileSync(join(here, "fixtures/legacy-DEMONSTRACAO.json"), "utf8"));
const {server, port} = await startServer(root, 0, "/"); const base = `http://127.0.0.1:${port}/`;
const br = await chromium.launch();
async function mk(url, {w = 1280, h = 800, seed = null} = {}){
  const ctx = await br.newContext({viewport:{width:w, height:h}, acceptDownloads:true}); const errs = [];
  if (seed) await ctx.addInitScript(s => { if (!localStorage.getItem("__seeded")){ localStorage.setItem("__seeded", "1"); for (const [k, v] of Object.entries(s)) localStorage.setItem(k, v); } }, seed);
  const page = await ctx.newPage();
  page.on("pageerror", e => errs.push("pageerror: " + e.message)); page.on("console", m => m.type() === "error" && errs.push("console: " + m.text()));
  page.on("response", r => r.status() >= 400 && errs.push("HTTP " + r.status() + " " + r.url()));
  await page.goto(url); await page.waitForLoadState("networkidle"); return {ctx, page, errs};
}
const addQ = async (p, n, s, v, st = "pending") => { await p.click("#newQuote"); await p.fill("#quoteForm [name=name]", n); await p.fill("#quoteForm [name=service]", s); await p.fill("#quoteForm [name=value]", String(v)); await p.selectOption("#quoteForm [name=status]", st); await p.click("#quoteForm button[type=submit]"); };
const txt = (p, sel) => p.$eval(sel, e => e.textContent.trim());
const nav = (p, n) => p.click(`.nav button[data-page="${n}"]`);
const rows = p => p.$$eval("#quotesBody tr", t => t.filter(r => !r.querySelector(".empty")).length);
const dl = async (p, sel) => { const [d] = await Promise.all([p.waitForEvent("download"), p.click(sel)]); return readFileSync(await d.path(), "utf8"); };
const ls = (p, k) => p.evaluate(k => localStorage.getItem(k), k);
const keys = p => p.evaluate(() => Object.keys(localStorage));
const wait = (p, ms = 400) => p.waitForTimeout(ms);

// ===== A. Funcionalidades (versão modular) =====
{ const {ctx, page:p, errs} = await mk(base);
  t("A1 carrega sem erros de script nem 404", errs.length === 0, errs.join(" | "));
  t("A2 estado inicial vazio e sem dados fictícios", await txt(p, "#mCount") === "0" && (await txt(p, "#quotesBody")).includes("Nenhum orçamento ainda") && (await txt(p, "#chartNote")).includes("Nenhum orçamento criado"));
  await addQ(p, "Cliente Um", "Corte", 120.5, "review"); await addQ(p, "Cliente Dois", "Barba", 80);
  t("A3 criação: linhas, contadores, valor e clientes", await rows(p) === 2 && await txt(p, "#mCount") === "2" && await txt(p, "#mClients") === "2" && (await txt(p, "#mValue")).includes("200,50") && await txt(p, "#mOpen") === "2");
  t("A3b criação aparece em Atividades recentes", (await txt(p, "#activityList")).includes("Cliente Dois"));
  await p.selectOption("#quotesBody tr:first-child select", "approved");
  t("A4 mudança de status atualiza pendentes e persiste na tela", await txt(p, "#mOpen") === "1" && await p.$eval("#quotesBody tr:first-child select", e => e.value) === "approved");
  await p.selectOption("#statusFilter", "approved"); const f1 = await rows(p);
  await p.selectOption("#statusFilter", "review"); const f2 = await rows(p);
  await p.selectOption("#statusFilter", ""); const f3 = await rows(p);
  t("A5 filtros por status", f1 === 1 && f2 === 1 && f3 === 2, [f1, f2, f3]);
  await p.click("#quotesBody tr:first-child .text-btn");
  t("A6 exclusão", await rows(p) === 1 && await txt(p, "#mCount") === "1");
  const n30 = await txt(p, "#chartNote"); await p.selectOption("#periodSelect", "7");
  t("A7 gráfico do dashboard e troca de período", n30.includes("1 orçamento criado em 30 dias") && (await txt(p, "#chartNote")).includes("em 7 dias"), n30);
  await nav(p, "Clientes"); const cl = await txt(p, "#clientsBody"); await nav(p, "Relatórios"); const rp = await txt(p, "#reportsBody");
  t("A7b Clientes e Relatórios refletem os dados", cl.includes("Cliente Um") && rp.includes("Ticket médio") && rp.includes("Em análise1"), cl + " / " + rp);
  await p.reload(); await p.waitForLoadState("networkidle");
  t("A8 persistência após recarregar", await txt(p, "#mCount") === "1");
  await addQ(p, 'Ana "A"; B', "Sv", 10); const csv = await dl(p, "#exportButton");
  t("A9 exportação CSV (BOM, cabeçalho, aspas e ponto e vírgula)", csv.charCodeAt(0) === 0xFEFF && csv.includes('"Cliente";"Serviço";"Valor";"Data";"Status"') && csv.includes('"Ana ""A""; B";"Sv";"10.00"'), JSON.stringify(csv.slice(0, 160)));
  await nav(p, "Configurações"); await p.fill("#bizName", "Barbearia Teste"); await p.click("#saveBiz");
  t("A10 configurações: nome do negócio aplicado", await txt(p, ".profile-name") === "Barbearia Teste");
  await p.reload(); await p.waitForLoadState("networkidle");
  t("A10b nome do negócio persiste", await txt(p, ".profile-name") === "Barbearia Teste");
  await nav(p, "Configurações"); await p.click("#clearData"); const armed = await txt(p, "#clearData"); await p.click("#clearData");
  t("A10c apagar exige dois cliques e zera os orçamentos", armed.includes("Clique de novo") && await txt(p, "#mCount") === "0");
  await nav(p, "Atendimentos");
  t("A11 Atendimentos continua como aviso de 'em desenvolvimento'", (await txt(p, "#toast")).includes("em desenvolvimento"));
  await nav(p, "Assistente IA"); await p.fill("#chatInput", "oi"); await p.press("#chatInput", "Enter");
  await p.waitForFunction(() => [...document.querySelectorAll(".msg.bot")].pop().textContent.includes("publicada"));
  t("A12 assistente fora do Claude mostra o aviso de indisponibilidade", true);
  const tr = await p.evaluate(async () => { const m = await import(new URL("assets/js/modules/assistente/view.js", document.baseURI).href);
    const a = m.tools[0].execute({cliente:"Via IA", servico:"Teste", valor:50}); const b = m.tools[1].execute({cliente:"Via IA", status:"approved"}); let err = null;
    try { m.tools[0].execute({cliente:"", servico:"x", valor:1}); } catch (e) { err = e.message; }
    return {a, b, err, c:document.getElementById("mCount").textContent, o:document.getElementById("mOpen").textContent}; });
  t("A12b ferramentas do assistente (chamadas diretamente) salvam, mudam status e validam", tr.c === "1" && tr.o === "0" && tr.err === "Dados incompletos", JSON.stringify(tr));
  t("A13 nenhum erro de script durante todo o fluxo funcional", errs.length === 0, errs.join(" | "));
  await ctx.close(); }

// ===== B. Responsividade / menu móvel =====
{ const {ctx, page:p, errs} = await mk(base, {w:390, h:800});
  const r0 = await p.$eval("#sidebar", e => e.getBoundingClientRect().right); await p.click("#menuToggle"); await wait(p);
  const l1 = await p.$eval("#sidebar", e => e.getBoundingClientRect().left); await nav(p, "Clientes"); await wait(p);
  const r2 = await p.$eval("#sidebar", e => e.getBoundingClientRect().right);
  t("B1 menu móvel: fechado, abre pelo botão e fecha ao navegar", r0 <= 0 && l1 >= -1 && r2 <= 0, [r0, l1, r2]);
  t("B2 sem rolagem horizontal em 390px", await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth) && errs.length === 0);
  await ctx.close(); }

// ===== C. Migração do localStorage =====
const raw = JSON.stringify(fx.quotes), seed = {"veltronix-flow-quotes":raw, "veltronix-flow-biz":fx.biz};
{ const {ctx, page:p, errs} = await mk(base, {seed});
  const meta = JSON.parse(await ls(p, "vf:v2:meta")), v2 = JSON.parse(await ls(p, "vf:v2:orcamentos")), q = JSON.parse(await ls(p, "vf:v2:quarentena"));
  const bk = (await keys(p)).filter(k => k.startsWith("vf:backup:v1:")); const bkv = bk.length ? JSON.parse(await ls(p, bk[0])) : {};
  t("C1 chaves antigas intactas após migrar", await ls(p, "veltronix-flow-quotes") === raw && await ls(p, "veltronix-flow-biz") === fx.biz);
  t("C2 snapshot do original gravado com o texto exato", bk.length === 1 && bkv.quotesRaw === raw && bkv.bizRaw === fx.biz);
  t("C3 resultado: 3 migrados (2 reais + 1 demo), 2 em quarentena", meta.schemaVersion === 2 && meta.migrados === 3 && meta.quarentena === 2 && v2.length === 3 && q.length === 2 && v2.filter(r => r.origem === "demo").length === 1, JSON.stringify(meta));
  t("C3b valores em centavos inteiros e ids únicos", v2.every(r => Number.isInteger(r.valueCents) && r.id) && new Set(v2.map(r => r.id)).size === 3 && v2.find(r => r.name === "Cliente Real A").valueCents === 10010);
  t("C4 tela mostra só dados reais; demo oculto; nome do negócio migrado", await txt(p, "#mCount") === "2" && (await txt(p, "#mValue")).includes("155,10") && await txt(p, ".profile-name") === fx.biz);
  t("C5 aviso de migração exibido", (await txt(p, "#toast")).includes("migrado"));
  await p.reload(); await p.waitForLoadState("networkidle");
  t("C6 idempotente: recarregar não cria novo backup nem altera dados", (await keys(p)).filter(k => k.startsWith("vf:backup:v1:")).length === 1 && JSON.stringify(JSON.parse(await ls(p, "vf:v2:orcamentos"))) === JSON.stringify(v2));
  await addQ(p, "Novo Real", "Teste", 10); const v2b = JSON.parse(await ls(p, "vf:v2:orcamentos"));
  t("C7 usar o app não toca nas chaves antigas e preserva o registro demo", await ls(p, "veltronix-flow-quotes") === raw && v2b.length === 4 && v2b.filter(r => r.origem === "demo").length === 1);
  t("C8 sem erros no console", errs.length === 0, errs.join(" | "));
  await ctx.close(); }
{ const {ctx, page:p} = await mk(base, {seed:{"veltronix-flow-quotes":"{não é json", "veltronix-flow-biz":""}});
  const meta = JSON.parse(await ls(p, "vf:v2:meta"));
  t("C9 JSON corrompido: vai para quarentena, original intacto, app abre vazio", meta.migrados === 0 && meta.quarentena === 1 && await ls(p, "veltronix-flow-quotes") === "{não é json" && await txt(p, "#mCount") === "0"); await ctx.close(); }
{ const {ctx, page:p} = await mk(base);
  const meta = JSON.parse(await ls(p, "vf:v2:meta"));
  t("C10 instalação nova: sem backup e sem dados", meta.origem === "instalacao-nova" && (await keys(p)).every(k => !k.startsWith("vf:backup"))); await ctx.close(); }

// ===== D. Exportar / importar backup =====
{ const {ctx, page:p} = await mk(base); await addQ(p, "Cliente Um", "Corte", 120.5, "review"); await addQ(p, "Cliente Dois", "Barba", 80);
  await nav(p, "Configurações"); const js = await dl(p, "#exportBackup"); const ex = JSON.parse(js);
  t("D1 exportação gera JSON válido, completo e sem alterar dados", ex.app === "veltronix-flow" && ex.formato === 1 && ex.orcamentos.length === 2 && ex.orcamentos.every(r => Number.isInteger(r.valueCents)));
  const imp = async (obj) => { await p.setInputFiles("#importFile", {name:"b.json", mimeType:"application/json", buffer:Buffer.from(typeof obj === "string" ? obj : JSON.stringify(obj))}); await p.waitForFunction(() => document.getElementById("backupMsg").textContent.length > 0); const m = await txt(p, "#backupMsg"); return m; };
  const before = await ls(p, "vf:v2:orcamentos");
  let m = await imp(ex); t("D2 importar o mesmo arquivo não duplica (0 adicionados, 2 ignorados)", m.includes("0 adicionados") && m.includes("2 já existiam") && await ls(p, "vf:v2:orcamentos") === before, m);
  ex.orcamentos.push({name:"Cliente Três", service:"Novo", valueCents:5000, date:"2026-10-15", status:"pending"});
  await p.evaluate(() => (document.getElementById("backupMsg").textContent = "")); m = await imp(ex);
  const after = JSON.parse(await ls(p, "vf:v2:orcamentos"));
  t("D3 importar com 1 novo adiciona só o novo e cria snapshot", m.includes("1 adicionados") && after.length === 3 && (await keys(p)).some(k => k.startsWith("vf:backup:import:")), m);
  await nav(p, "Dashboard"); t("D3b tela atualiza após importar", await txt(p, "#mCount") === "3");
  await nav(p, "Configurações"); const snap = await ls(p, "vf:v2:orcamentos");
  await p.evaluate(() => (document.getElementById("backupMsg").textContent = "")); m = await imp("isto não é json");
  t("D4 arquivo inválido: erro claro e nada gravado", m.includes("JSON válido") && m.includes("Nada foi gravado") && await ls(p, "vf:v2:orcamentos") === snap, m);
  await p.evaluate(() => (document.getElementById("backupMsg").textContent = "")); m = await imp({app:"veltronix-flow", formato:1, orcamentos:[{name:"", service:"x", valueCents:1, date:"2026-10-01", status:"pending"}, {name:"Ok", service:"x", valueCents:-5, date:"2026-10-01", status:"pending"}]});
  t("D5 registros inválidos: lista os erros e não grava nada (nem os válidos)", m.includes("Orçamento 1: cliente vazio") && m.includes("Orçamento 2: valor inválido") && await ls(p, "vf:v2:orcamentos") === snap, m);
  await p.evaluate(() => (document.getElementById("backupMsg").textContent = "")); m = await imp({app:"outro", orcamentos:[]});
  t("D6 arquivo de outro aplicativo é recusado", m.includes("não reconhecido") && await ls(p, "vf:v2:orcamentos") === snap, m);
  await ctx.close(); }

// ===== E. Hospedagem em subpasta + caminhos =====
{ const s2 = await startServer(root, 0, "/app/x/"); const b2 = `http://127.0.0.1:${s2.port}/app/x/`;
  const {ctx, page:p, errs} = await mk(b2); await addQ(p, "Sub", "Pasta", 5); await p.reload(); await p.waitForLoadState("networkidle");
  t("E1 funciona em subpasta (/app/x/) sem 404 e persiste", errs.length === 0 && await txt(p, "#mCount") === "1", errs.join(" | "));
  const r = await fetch(base + "Assets/js/app.js"); t("E2 servidor sensível a maiúsculas devolve 404 para caminho com caixa errada", r.status === 404);
  await ctx.close(); s2.server.close(); }
{ const bad = []; const walk = d => readdirSync(d).flatMap(f => { const p = join(d, f); return statSync(p).isDirectory() ? walk(p) : [p]; });
  const files = [join(root, "index.html"), ...walk(join(root, "assets"))];
  for (const f of files){ const c = readFileSync(f, "utf8");
    if (/(src|href)="\/(?!\/)/.test(c) || /from\s+"\/|import\("\//.test(c)) bad.push("caminho absoluto em " + f);
    if (/https?:\/\//.test(c.replace(/http:\/\/www\.w3\.org\/\d+\/\w+/g, ""))) bad.push("URL externa em " + f);
    if (f.endsWith(".js")) for (const m of c.matchAll(/from\s+"(\.[^"]+)"|import\s+"(\.[^"]+)"/g)){ const spec = m[1] || m[2]; const target = join(dirname(f), spec); if (!existsSync(target)) bad.push("import inexistente: " + spec + " em " + f); } }
  t("E3 (verificação estática executada) sem caminhos absolutos, sem URLs externas e todos os imports existem", bad.length === 0, bad.join("; ")); }

// ===== F. Ponte: página antiga com exportação -> importação na versão modular =====
{ const {ctx, page:p, errs} = await mk(base + "legacy/index.v1.3-com-exportacao.html");
  await addQ(p, "Ponte Teste", "Serviço P", 99.9, "approved"); await addQ(p, "Outro", "S", 10);
  const q0 = await ls(p, "veltronix-flow-quotes"); await nav(p, "Configurações"); const js = await dl(p, "#exportBackup"); const ex = JSON.parse(js);
  t("F1 exportação da página antiga é somente leitura e gera formato importável", await ls(p, "veltronix-flow-quotes") === q0 && ex.orcamentos.length === 2 && ex.orcamentos.some(r => r.valueCents === 9990), errs.join("|"));
  await ctx.close();
  const b = await mk(base); await nav(b.page, "Configurações"); await b.page.setInputFiles("#importFile", {name:"ponte.json", mimeType:"application/json", buffer:Buffer.from(js)});
  await b.page.waitForFunction(() => document.getElementById("backupMsg").textContent.length > 0); await nav(b.page, "Dashboard");
  t("F2 dados da página antiga chegam à versão modular via importação", await txt(b.page, "#mCount") === "2" && (await txt(b.page, "#quotesBody")).includes("Ponte Teste") && (await txt(b.page, "#mValue")).includes("109,90"));
  await b.ctx.close(); }

// ===== G. Equivalência com o original (v1.3) =====
async function scenario(p){ const o = {};
  await addQ(p, "Cliente Um", "Corte", 120.5, "review"); await addQ(p, "Cliente Dois", "Barba", 80);
  await p.selectOption("#quotesBody tr:first-child select", "approved");
  o.metricas = await p.$$eval("#mCount,#mOpen,#mValue,#mClients", e => e.map(x => x.textContent));
  o.linhas = await p.$$eval("#quotesBody tr", t => t.map(r => r.innerText.replace(/\s+/g, " ").trim()));
  await p.selectOption("#statusFilter", "approved"); o.filtrado = await p.$$eval("#quotesBody tr", t => t.length); await p.selectOption("#statusFilter", "");
  o.atividade = await txt(p, "#activityList"); o.grafico = await txt(p, "#chartNote"); o.eixo = await p.$$eval(".chart-label text", e => e.map(x => x.textContent));
  await nav(p, "Clientes"); o.clientes = await txt(p, "#clientsBody"); await nav(p, "Relatórios"); o.relatorios = await p.$eval("#reportsBody", e => e.innerText);
  await nav(p, "Dashboard"); o.csv = await dl(p, "#exportButton"); await p.click("#quotesBody tr:first-child .text-btn"); o.aposExcluir = await txt(p, "#mCount"); return o; }
{ const a = await mk(base + "backup/index.v1.3.backup.html"), b = await mk(base);
  const oa = await scenario(a.page), ob = await scenario(b.page);
  const diff = Object.keys(oa).filter(k => JSON.stringify(oa[k]) !== JSON.stringify(ob[k]));
  t("G1 mesmo cenário no original v1.3 e na versão modular produz resultados idênticos", diff.length === 0, "difere em: " + diff.join(",")); await a.ctx.close(); await b.ctx.close(); }
if (sharp){
  for (const [w, h] of [[1280, 800], [820, 900], [390, 800]]) for (const estado of ["vazio", "com dados"]){
    const a = await mk(base + "backup/index.v1.3.backup.html", {w, h}), b = await mk(base, {w, h}); const shots = [];
    for (const x of [a, b]){ if (estado === "com dados"){ await addQ(x.page, "Cliente Um", "Corte", 120.5, "review"); await addQ(x.page, "Cliente Dois", "Barba", 80); }
      await x.page.addStyleTag({content:"*{transition:none!important;animation:none!important;caret-color:transparent!important} .footer{visibility:hidden!important}"}); await x.page.mouse.move(0, 0); await wait(x.page, 100); shots.push(await x.page.screenshot({fullPage:true})); }
    const [ra, rb] = await Promise.all(shots.map(s => sharp(s).raw().toBuffer({resolveWithObject:true})));
    let nd = -1; if (ra.info.width === rb.info.width && ra.info.height === rb.info.height){ nd = 0; for (let i = 0; i < ra.data.length; i += 4) if (ra.data[i] !== rb.data[i] || ra.data[i + 1] !== rb.data[i + 1] || ra.data[i + 2] !== rb.data[i + 2]) nd++; }
    t(`G2 captura de tela ${w}px (${estado}) idêntica ao original (exceto o texto de versão do rodapé, que mudou de propósito)`, nd === 0, nd < 0 ? "dimensões diferentes" : nd + " pixels diferentes"); await a.ctx.close(); await b.ctx.close(); }
} else t("G2 comparação visual por capturas", false, "sharp indisponível: não executado");

await br.close(); server.close();
const naoTestado = ["Conversa real do Assistente IA com o Claude (depende da página publicada no Claude; só a mensagem de indisponibilidade e as ferramentas foram exercitadas)", "Navegadores além do Chromium (Firefox, Safari) e aparelhos reais com toque", "Publicação real em hospedagem estática (apenas servidor local e subpasta simulados)", "Página já publicada no Claude (não foi alterada nem republicada)", "Exportação pelo recurso de downloads do Claude (só o caminho alternativo por link de download foi exercitado)"];
const ok = R.filter(r => r.ok).length;
writeFileSync(join(here, "resultados.json"), JSON.stringify({executadoEm:new Date().toISOString(), total:R.length, aprovados:ok, falhas:R.length - ok, resultados:R, naoTestado}, null, 2));
console.log(`\n${ok}/${R.length} aprovados`); process.exit(ok === R.length ? 0 : 1);
