import http from "node:http";
import {readFile} from "node:fs/promises";
import {extname, join, normalize, resolve} from "node:path";
import {fileURLToPath, pathToFileURL} from "node:url";
const T = {".html":"text/html; charset=utf-8", ".css":"text/css", ".js":"text/javascript", ".json":"application/json", ".md":"text/markdown"};
// Servidor estático mínimo (sem dependências). Diferencia maiúsculas/minúsculas, como a maioria das hospedagens.
export function startServer(root, port = 0, prefix = "/"){
  root = resolve(root);
  return new Promise(res => {
    const server = http.createServer(async (rq, rs) => {
      let p = decodeURIComponent(new URL(rq.url, "http://x").pathname);
      if (!p.startsWith(prefix)){ rs.writeHead(404); return rs.end("fora do prefixo"); }
      p = "/" + p.slice(prefix.length); if (p.endsWith("/")) p += "index.html";
      const f = normalize(join(root, p));
      if (!f.startsWith(root)){ rs.writeHead(403); return rs.end(); }
      try { const b = await readFile(f); rs.writeHead(200, {"content-type": T[extname(f)] || "application/octet-stream"}); rs.end(b); }
      catch { rs.writeHead(404); rs.end("não encontrado"); }
    });
    server.listen(port, "127.0.0.1", () => res({server, port:server.address().port}));
  });
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href){
  const here = fileURLToPath(new URL("..", import.meta.url));
  const {port} = await startServer(here, Number(process.argv[2]) || 8080);
  console.log("VELTRONIX FLOW em http://127.0.0.1:" + port + "/");
}
