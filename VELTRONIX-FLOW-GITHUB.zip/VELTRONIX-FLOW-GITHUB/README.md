# VELTRONIX FLOW — Fase 1 (versão modular)

Painel de gestão para pequenos negócios. HTML + CSS + JavaScript puro (módulos nativos do navegador), sem framework, sem build, sem dependências em produção. **Sem Supabase, login ou APIs nesta fase.**

## Estrutura
```
index.html                 casca da página (mesmo HTML visual da v1.3)
assets/css/                tokens · base · layout · components (+ responsivo), na mesma ordem do CSS original
assets/js/app.js           inicialização
assets/js/core/            store · registry (menu/navegação) · format · ui
assets/js/services/        boot · migration · files · ai
assets/js/repositories/local/   storage · orcamentosRepo · configRepo
assets/js/modules/         orcamentos · dashboard · clientes · relatorios · assistente · configuracoes · atendimentos
tests/                     run.mjs (testes) · server.mjs (servidor estático) · fixtures/ (dados de DEMONSTRAÇÃO)
docs/                      INVENTARIO.md · RELATORIO-FASE1.md
backup/                    cópia exata da v1.3 + SHA256SUMS.txt
legacy/                    v1.3 + botão "Exportar backup (JSON)" (arquivo único)
```

## Como executar
Módulos nativos **não abrem com duplo clique** (file://). Sirva a pasta por HTTP:
```
node tests/server.mjs 8080        # abre http://127.0.0.1:8080/
# ou: python3 -m http.server 8080
```

## Como publicar (hospedagem estática)
Envie a pasta inteira (os diretórios `tests/`, `backup/`, `legacy/` e `docs/` são opcionais em produção). Todos os caminhos são relativos, então funciona na raiz do domínio ou em subpasta (testado em `/app/x/`). Use HTTPS. Hospedagens têm planos gratuitos, mas confira as regras de uso comercial de cada plano antes de escolher.

## Como rodar os testes
Requer Node 18+ e Playwright (gratuito, só para desenvolvimento): `npm i -D playwright && npx playwright install chromium`, depois `node tests/run.mjs`. O resultado fica em `tests/resultados.json`.

## Como testar a migração manualmente
1. Sirva a pasta (`node tests/server.mjs 8080`).
2. Abra `http://127.0.0.1:8080/backup/index.v1.3.backup.html` e crie alguns orçamentos (versão antiga).
3. Na **mesma origem** (mesmo endereço e porta), abra `http://127.0.0.1:8080/`. A migração roda sozinha e mostra um aviso.
4. No DevTools (Application → Local Storage) confira: `veltronix-flow-quotes` e `veltronix-flow-biz` intactas; `vf:backup:v1:…` com o texto original; `vf:v2:*` com os dados convertidos; `vf:v2:quarentena` com registros inválidos (se houver).

## Migrar dados de outra origem (ex.: a página publicada no Claude)
O `localStorage` não atravessa endereços. Com `legacy/index.v1.3-com-exportacao.html` (a v1.3 com o botão "Exportar backup") aberto **no endereço onde estão os dados**, use Configurações → Exportar backup (JSON). Na versão modular, Configurações → Importar backup. A importação valida tudo antes de gravar, não duplica e não sobrescreve. **Atenção:** para exportar da página já publicada no Claude seria preciso republicá-la com o botão; isso não foi feito (a Fase 1 foi instruída a não publicar por cima).

## Como reverter
- **Código:** use `backup/index.v1.3.backup.html` (confira com `sha256sum -c SHA256SUMS.txt` dentro de `backup/`) renomeado para `index.html`. Abre com duplo clique.
- **Dados:** as chaves antigas nunca são alteradas, então a v1.3 continua lendo seus dados. Para desfazer a migração, apague só as chaves `vf:` (DevTools → Console: `Object.keys(localStorage).filter(k => k.startsWith("vf:")).forEach(k => localStorage.removeItem(k))`). **Antes disso, exporte um backup**: o que foi criado depois da migração existe apenas nas chaves `vf:`.
- Se a migração falhar, o app abre vazio e registra a falha em `vf:v2:meta`; os dados antigos continuam intactos e podem ser reaproveitados via exportação pelo arquivo `legacy/` + importação.

## Limitações conhecidas
Veja `docs/RELATORIO-FASE1.md`.
