# Como publicar o VELTRONIX FLOW no GitHub Pages

## Antes de começar
- Publique esta versão em um repositório de teste separado, sem substituir o site atual.
- O sistema desta fase usa armazenamento local do navegador; ainda não tem Supabase nem login.
- O backup da versão anterior está na pasta `backup/`.

## Enviar os arquivos
1. Extraia o ZIP no computador.
2. No GitHub, crie um repositório novo, por exemplo `veltronix-flow-teste`.
3. Abra o repositório e use **Add file → Upload files**.
4. Envie o conteúdo da pasta extraída, mantendo as pastas `assets`, `tests`, `docs`, `backup`, `legacy` e os outros arquivos. O `index.html` deve ficar na raiz do repositório.
5. Clique em **Commit changes**.

## Ativar o GitHub Pages
1. No repositório, abra **Settings → Pages**.
2. Em **Build and deployment**, escolha **Deploy from a branch**.
3. Escolha a branch `main` e a pasta `/(root)`.
4. Clique em **Save** e aguarde a URL aparecer nessa mesma tela.

## Observações
- Não abra o `index.html` por duplo clique para testar: ele usa módulos JavaScript. GitHub Pages serve os arquivos por HTTPS e é adequado para visualização.
- Os dados ficam no armazenamento local do navegador e não são compartilhados entre dispositivos ou navegadores.
- Não use dados reais de clientes para testes.
- Esta publicação de teste não migra automaticamente os dados guardados na versão anterior.
